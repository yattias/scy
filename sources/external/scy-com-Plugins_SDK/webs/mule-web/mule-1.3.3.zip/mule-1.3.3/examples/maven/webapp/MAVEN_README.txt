Currently the Mule distribution provides an Ant build script for the Mule Examples Webapp
You can build the Webapp by going to $MULE_HOME/examples/ant/webapp and running 'ant'
(you'll need to have Ant installed: http://ant.apache.org)