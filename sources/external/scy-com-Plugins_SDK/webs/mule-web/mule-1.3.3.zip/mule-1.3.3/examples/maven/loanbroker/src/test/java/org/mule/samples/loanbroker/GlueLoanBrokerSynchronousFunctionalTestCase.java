/*
 * $Id: GlueLoanBrokerSynchronousFunctionalTestCase.java 4219 2006-12-09 10:15:14Z lajos $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the MuleSource MPL
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.samples.loanbroker;

public class GlueLoanBrokerSynchronousFunctionalTestCase extends AxisLoanBrokerSynchronousFunctionalTestCase
{

    public GlueLoanBrokerSynchronousFunctionalTestCase()
    {
        super();
    }
    
    protected String getConfigResources()
    {
        return "loan-broker-glue-sync-test-config.xml";
    }

    protected int getNumberOfRequests()
    {
        return 100;
    }

}
