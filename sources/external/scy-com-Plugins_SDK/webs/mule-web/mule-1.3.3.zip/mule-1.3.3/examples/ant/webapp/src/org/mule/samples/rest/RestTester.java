/*
 * $Id: RestTester.java 3798 2006-11-04 04:07:14Z aperepel $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the MuleSource MPL
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.samples.rest;

import org.mule.components.simple.StaticComponent;

/**
 * TODO This is a bogus class that has been put here so that the Corbertura plugin
 * does not barf, we need to find a way to get this plug in to ignore certain modules
 */
public class RestTester extends StaticComponent
{
    // nothing here
}
