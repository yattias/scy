The Mule examples can be built using either of the following build tools:
	Ant (version 1.6.5 or newer)   http://ant.apache.org
	Maven (version 2.0 or newer)   http://maven.apache.org

Although Maven aims to make your build simple, the process itself is quite complex, so
if you are not familiar with either tool, you will most likely want to start with Ant.

Many of the examples are ready to run out-of-the-box and it is not necessary for you
to build them.  However, some require additional libraries not included as part of the
Mule distribution.  When this is the case, the additional libraries will be downloaded
into the $MULE_HOME/lib/user directory upon building the example.
