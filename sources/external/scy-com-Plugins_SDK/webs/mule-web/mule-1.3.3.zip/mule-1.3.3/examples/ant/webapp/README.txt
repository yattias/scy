+-----------------+
| Web App Example |
+-----------------+

The Mule Webapp provides a user interface to some of the Mule examples such
as the LoanBroker, Hello World and Echo examples. It also provides examples of
accessing Mule using REST style service calls and is itself an example of how
to embed Mule in a webapp.

The generated WAR file can be deployed to any standard J2EE web server.
