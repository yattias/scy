package eu.scy.client.tools.fxchattool.registration;

public interface ListInput {

    public void getList (String[] v);

}
