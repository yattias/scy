package eu.scy.client.tools.fxchattool.registration;

public interface ChatInput {

    public void gotText (String t);

}
